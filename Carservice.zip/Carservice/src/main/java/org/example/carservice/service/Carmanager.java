package org.example.carservice.service;

import org.example.carservice.dto.Cardto;

import java.util.List;

public class Carmanager implements Carservice {
    /**
     * @param cardto
     * @return
     */
    @Override
    public Cardto saveCar(Cardto cardto) {
        return null;
    }

    /**
     * @param matricul
     * @return
     */
    @Override
    public boolean deleteCar(String matricul) {
        return false;
    }

    /**
     * @param model
     * @return
     */
    @Override
    public Cardto getCarByModel(String model) {
        return null;
    }

    /**
     * @param model
     * @param price
     * @return
     */
    @Override
    public Cardto getCarByModelAndPrice(String model, double price) {
        return null;
    }

    /**
     * @return
     */
    @Override
    public List<Cardto> getAllCar() {
        return List.of();
    }
}
