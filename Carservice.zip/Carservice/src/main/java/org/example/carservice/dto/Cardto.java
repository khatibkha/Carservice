package org.example.carservice.dto;

import lombok.Data;

@Data
public class Cardto {
    private String model;
    private String color;
    private String matricul;
    private double price;
}

