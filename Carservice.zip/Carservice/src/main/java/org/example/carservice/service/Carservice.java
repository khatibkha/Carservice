package org.example.carservice.service;

import org.example.carservice.dao.entities.Car;
import org.example.carservice.dto.Cardto;

import java.util.List;

public interface Carservice {
    static void addCar(Car car4) {
    }

    Cardto saveCar(Cardto cardto);

    boolean deleteCar(String matricul);

    Cardto getCarByModel(String model);

    Cardto getCarByModelAndPrice(String model, double price);

    List<Cardto> getAllCar();
}
