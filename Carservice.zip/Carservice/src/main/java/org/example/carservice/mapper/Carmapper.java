package org.example.carservice.mapper;

import org.example.carservice.dao.entities.Car;
import org.example.carservice.dto.Cardto;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
public class Carmapper {
    ModelMapper mapper = new ModelMapper();

    public Cardto toDto(Car car) {
        return mapper.map(car, Cardto.class);
    }

    public Car toDto(Cardto cardto) {
        return mapper.map(cardto, Car.class);
    }
}
