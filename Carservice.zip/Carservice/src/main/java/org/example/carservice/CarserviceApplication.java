package org.example.carservice;

import org.example.carservice.dao.entities.Car;
import org.example.carservice.dto.Cardto;
import org.example.carservice.service.Carservice;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.List;

import static org.example.carservice.service.Carservice.*;

@SpringBootApplication
public class CarserviceApplication {

    public static void main(String[] args) {
        SpringApplication.run(CarserviceApplication.class, args);
    }
public class Main {
        public static void main(String[] args) {
            Carservice carservice = new Carservice() {
                /**
                 * @param cardto
                 * @return
                 */
                @Override
                public Cardto saveCar(Cardto cardto) {
                    return null;
                }

                /**
                 * @param matricul
                 * @return
                 */
                @Override
                public boolean deleteCar(String matricul) {
                    return false;
                }

                /**
                 * @param model
                 * @return
                 */
                @Override
                public Cardto getCarByModel(String model) {
                    return null;
                }

                /**
                 * @param model
                 * @param price
                 * @return
                 */
                @Override
                public Cardto getCarByModelAndPrice(String model, double price) {
                    return null;
                }

                /**
                 * @return
                 */
                @Override
                public List<Cardto> getAllCar() {
                    return List.of();
                }
            };
            Car car1 = new Car(1,"toyota","rouge",23/2/22,230004330);
            Car car2 = new Car(3,"mercedes","jaune",23/3/22,23045000);
            Car car3 = new Car(4,"bugatti","jaune",23/4/22,23460000);
            Car car4 = new Car(5,"bmw","vert",23/2/6622,23440000);

            Carservice.addCar(car1);
            Carservice.addCar(car3);
            Carservice.addCar(car4);

            // Affichage des voitures
            carservice.getAllCar().forEach(System.out::println);

}

}
}
