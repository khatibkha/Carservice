package org.example.carservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
